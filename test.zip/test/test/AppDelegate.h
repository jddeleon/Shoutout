//
//  AppDelegate.h
//  test
//
//  Created by Eric Yang on 4/9/13.
//
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
