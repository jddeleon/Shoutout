//
//  RootViewController.m
//  test
//
//  Created by Eric Yang on 4/9/13.
//
//

#import "RootViewController.h"
#import "MyViewController.h"

@interface RootViewController ()

@end

@implementation RootViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    button.frame = CGRectMake(50.0f, 100.0f, 200.0f, 40.0f);
    [button setTitle:@"Tap To Modal" forState:UIControlStateNormal];
    [button addTarget:self action:@selector(buttonAction:) forControlEvents:UIControlEventTouchUpInside];
    button.tag = 100;
    [self.view addSubview:button];
    
}

- (void)buttonAction:(id)sender
{
    UITabBarController *controller = [[UITabBarController alloc] init];
    NSMutableArray *controllers = [@[] mutableCopy];
    for (int i = 0; i < 4; i ++) {
        [controllers addObject:[[UINavigationController alloc] initWithRootViewController:[[MyViewController alloc] init]]];
    }
    [controller setViewControllers:controllers];
    [self presentViewController:controller animated:YES completion:nil];
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
