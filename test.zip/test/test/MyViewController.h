//
//  MyViewController.h
//  test
//
//  Created by Eric Yang on 4/9/13.
//
//

#import <UIKit/UIKit.h>

@interface MyViewController : UIViewController

@end
